import java.util.ArrayList;
import java.util.List;

class Main {
  public static void main(String[] args) {
    System.out.println("Java hello world!");
    List<Integer> list = new ArrayList<>();
    for (int i = 0; i < 100; i++) {
      list.add(i * i);
    }
    
    for (int val : list) {
     System.out.println(val); 
    }
    
    System.exit(0);
  }
}